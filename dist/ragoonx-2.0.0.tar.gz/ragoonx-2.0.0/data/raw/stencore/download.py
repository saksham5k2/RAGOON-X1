from datasets import load_dataset
import json
from pathlib import Path

OUTPUT = Path(__file__).parent / "stencore_10k.jsonl"
LIMIT = 10_000

print("Loading StenCore-PDF...")

dataset = load_dataset(
    "StentorLabs/StenCore-PDF",
    split="train",
    streaming=True,
)

count = 0

with open(
    OUTPUT,
    "w",
    encoding="utf-8",
) as f:

    for row in dataset:

        record = {
            "text": row.get("text", ""),
            "source": row.get("source", ""),
            "source_url": row.get("source_url", ""),
            "license": row.get("license", ""),
        }

        # Skip empty documents
        if not record["text"].strip():
            continue

        f.write(
            json.dumps(
                record,
                ensure_ascii=False,
            )
            + "\n"
        )

        count += 1

        if count % 1000 == 0:
            print(
                f"Downloaded {count:,}/{LIMIT:,}"
            )

        if count >= LIMIT:
            break

print()
print(f"Done. Saved {count:,} documents.")
print(f"Output: {OUTPUT}")